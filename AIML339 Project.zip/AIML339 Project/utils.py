# utils.py
import os
import json
import random
import math
import time
from datetime import datetime
import torch
import numpy as np

def set_seed(seed=12345):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    # deterministic flags
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def ensure_dirs(dirs):
    for d in dirs:
        os.makedirs(d, exist_ok=True)

def save_hparams(path, hparams):
    with open(path, 'w') as f:
        json.dump(hparams, f, indent=2)

def load_json(path):
    with open(path, 'r') as f:
        return json.load(f)

def perplexity_from_loss(loss):
    return float(math.exp(min(100.0, loss)))  # cap to avoid overflow

def timestamp():
    return datetime.utcnow().strftime("%Y%m%d_%H%M%S")

def save_sample_text(path, text):
    with open(path, 'a', encoding='utf-8') as f:
        f.write(text + "\n\n" + ("-"*60) + "\n\n")
