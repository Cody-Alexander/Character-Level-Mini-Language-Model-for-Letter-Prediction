# eval_report.py
import os
import csv
from train import compute_checkpoint_metrics
from utils import ensure_dirs
ensure_dirs(["outputs"])

def evaluate_checkpoints(ckpt_list, out_csv="outputs/checkpoint_metrics.csv"):
    rows = []
    for ckpt in ckpt_list:
        print("evaluating", ckpt)
        m = compute_checkpoint_metrics(ckpt)
        rows.append({"checkpoint": ckpt, "loss": m["loss"], "accuracy": m["accuracy"], "perplexity": m["perplexity"]})
    # save csv
    with open(out_csv, 'w', newline='') as csvfile:
        fieldnames = ["checkpoint", "loss", "accuracy", "perplexity"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for r in rows:
            writer.writerow(r)
    print("saved metrics to", out_csv)

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--ckpts", nargs="+", required=True)
    args = parser.parse_args()
    evaluate_checkpoints(args.ckpts)
