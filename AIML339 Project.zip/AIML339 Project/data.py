# data.py
import torch
from config import vocab_file, block_size, batch_size, device

# read the dataset
with open(vocab_file, 'r', encoding='utf-8') as f:
    text = f.read()

# build vocabulary
chars = sorted(list(set(text)))
vocab_size = len(chars)
stoi = {ch: i for i, ch in enumerate(chars)}
itos = {i: ch for ch, i in stoi.items()}

# encoder/decoder
def encode(s):
    return [stoi[c] for c in s]

def decode(l):
    return ''.join([itos[i] for i in l])

# convert dataset to integers
data = torch.tensor(encode(text), dtype=torch.long)
split_idx = int(0.9 * len(data))
train_data = data[:split_idx]
val_data = data[split_idx:]

# batch generator
def get_batch(split):
    src = train_data if split == 'train' else val_data
    ix = torch.randint(len(src) - block_size, (batch_size,))
    x = torch.stack([src[i:i+block_size] for i in ix])
    y = torch.stack([src[i+1:i+block_size+1] for i in ix])
    return x.to(device), y.to(device)

# for testing
if __name__ == "__main__":
    xb, yb = get_batch('train')
    print("Input shape:", xb.shape)
    print("Target shape:", yb.shape)
    print("Decoded sample:", decode(xb[0].tolist()))
