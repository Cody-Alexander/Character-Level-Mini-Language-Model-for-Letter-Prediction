# train.py
import os
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
from model import TransformerModel
from data import get_batch, itos, encode, decode
from config import device, block_size
from utils import set_seed, ensure_dirs, save_hparams, perplexity_from_loss, timestamp, save_sample_text
import json

# directories
OUT = "outputs"
CHK = "checkpoints"
ensure_dirs([OUT, CHK])

# experiment hyperparameters 
hparams = {
    "seed": 12345,
    "max_iters": 100000,
    "eval_interval": 1000,
    "learning_rate": 1e-4,
    "warmup_steps": 200,
    "grad_clip": 1.0,
    "batch_size": None,  # filled from config at runtime
    "block_size": block_size,
    "embed_dim": None,   # filled in below
    "n_layers": None,
    "n_heads": None
}

# set seeds for reproducibility
set_seed(hparams["seed"])

# model and hyperparams sync
model = TransformerModel().to(device)
hparams["batch_size"] = model.token_embedding.num_embeddings and None  
# fill model dims
from config import embed_dim, n_layers, n_heads, batch_size
hparams["embed_dim"] = embed_dim
hparams["n_layers"] = n_layers
hparams["n_heads"] = n_heads
hparams["batch_size"] = batch_size

# optimizer and scheduler
optimizer = torch.optim.AdamW(model.parameters(), lr=hparams["learning_rate"])

max_iters = hparams["max_iters"]
eval_interval = hparams["eval_interval"]
warmup_steps = hparams["warmup_steps"]
grad_clip = hparams["grad_clip"]

def lr_lambda(step):
    if step < warmup_steps:
        return float(step) / float(max(1, warmup_steps))
    progress = float(step - warmup_steps) / float(max(1, max_iters - warmup_steps))
    return 0.5 * (1.0 + math.cos(math.pi * progress))

scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)

train_losses, val_losses, steps_logged = [], [], []

# helper evaluation (average of a few batches)
def evaluate(n=5):
    model.eval()
    total_loss = 0.0
    total_acc = 0.0
    with torch.no_grad():
        for _ in range(n):
            xb, yb = get_batch('val')
            logits, loss = model(xb, yb)
            total_loss += loss.item()
            # compute top1 char accuracy
            probs = logits.view(-1, logits.size(-1))
            targets = yb.view(-1)
            preds = torch.argmax(probs, dim=-1)
            total_acc += (preds == targets).float().mean().item()
    model.train()
    return total_loss / n, total_acc / n

# generation helper that accepts a prompt string
def generate_from_prompt(prompt, length=300, temperature=0.8):
    model.eval()
    device_local = device
    ids = torch.tensor([encode(prompt)], dtype=torch.long, device=device_local)
    out = ids
    with torch.no_grad():
        for _ in range(length):
            logits, _ = model(out[:, -block_size:])
            logits = logits[:, -1, :] / temperature
            probs = torch.softmax(logits, dim=-1)
            next_id = torch.multinomial(probs, num_samples=1)
            out = torch.cat([out, next_id], dim=1)
    model.train()
    return decode(out[0].tolist())

# save metrics + plots
def save_plots(train_losses, val_losses, eval_steps, outdir=OUT):
    import matplotlib.pyplot as plt
    plt.figure()
    plt.plot(eval_steps, train_losses, label="train")
    plt.plot(eval_steps, val_losses, label="val")
    plt.legend()
    plt.xlabel("steps")
    plt.ylabel("loss")
    path = os.path.join(outdir, "loss_curve.png")
    plt.savefig(path)
    plt.close()

# main training loop with optional resume
def train(resume_checkpoint=None, run_name=None):
    if run_name is None:
        run_name = f"run_{timestamp()}"
    meta = {"run_name": run_name, "hparams": hparams}
    save_hparams(os.path.join(OUT, f"{run_name}_hparams.json"), meta)

    start_step = 0
    if resume_checkpoint:
        print("loading checkpoint", resume_checkpoint)
        model.load_state_dict(torch.load(resume_checkpoint, map_location=device))
        # no optimizer state loaded by default for simplicity

    eval_steps = []
    for step in range(start_step, max_iters):
        xb, yb = get_batch('train')
        logits, loss = model(xb, yb)
        optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
        optimizer.step()
        scheduler.step()

        if (step + 1) % eval_interval == 0 or step == 0:
            val_loss, val_acc = evaluate(n=5)
            # compute train loss & acc quick
            model.eval()
            with torch.no_grad():
                xb_t, yb_t = get_batch('train')
                _, train_loss = model(xb_t, yb_t)
                logits_t, _ = model(xb_t, yb_t)
                preds_t = torch.argmax(logits_t.view(-1, logits_t.size(-1)), dim=-1)
                train_acc = (preds_t == yb_t.view(-1)).float().mean().item()
            model.train()

            train_losses.append(train_loss.item())
            val_losses.append(val_loss)
            step_num = step + 1
            eval_steps.append(step_num)
            print(f"Step {step_num}: Train {train_loss.item():.3f}, Val {val_loss:.3f}, train_acc {train_acc:.3f}, val_acc {val_acc:.3f}")

            # save checkpoint
            ckpt_name = os.path.join(CHK, f"{run_name}_ckpt_{step_num}.pt")
            torch.save(model.state_dict(), ckpt_name)

            # save a few generated samples at different temperatures
            for temp in [0.5, 0.8, 1.0]:
                prompt = "ROMEO:"
                sample = generate_from_prompt(prompt, length=200, temperature=temp)
                fname = os.path.join(OUT, f"{run_name}_sample_step{step_num}_temp{temp}.txt")
                with open(fname, 'w', encoding='utf-8') as f:
                    f.write(sample)

            # write a consolidated samples file
            combined_path = os.path.join(OUT, f"{run_name}_samples.txt")
            with open(combined_path, 'a', encoding='utf-8') as f:
                f.write(f"step {step_num}\n")
                for temp in [0.5, 0.8, 1.0]:
                    f.write(f"\n--- temp {temp} ---\n")
                    f.write(generate_from_prompt("ROMEO:", length=200, temperature=temp))
                    f.write("\n\n")

            # save plots so far
            save_plots(train_losses, val_losses, eval_steps, outdir=OUT)

    # final save
    torch.save(model.state_dict(), os.path.join(CHK, f"{run_name}_final.pt"))
    print("training complete, final model saved")

# small helper to compute final metrics for a checkpoint
def compute_checkpoint_metrics(checkpoint_path, n_eval_batches=20):
    model.load_state_dict(torch.load(checkpoint_path, map_location=device))
    model.eval()
    total_loss = 0.0
    total_acc = 0.0
    with torch.no_grad():
        for _ in range(n_eval_batches):
            xb, yb = get_batch('val')
            logits, loss = model(xb, yb)
            total_loss += loss.item()
            preds = torch.argmax(logits.view(-1, logits.size(-1)), dim=-1)
            total_acc += (preds == yb.view(-1)).float().mean().item()
    avg_loss = total_loss / n_eval_batches
    avg_acc = total_acc / n_eval_batches
    ppl = perplexity_from_loss(avg_loss)
    return {"loss": avg_loss, "accuracy": avg_acc, "perplexity": ppl}

# add main guard so can run as script
if __name__ == "__main__":
    import argparse, math
    parser = argparse.ArgumentParser()
    parser.add_argument("--resume", type=str, default=None, help="path to checkpoint to resume from")
    parser.add_argument("--name", type=str, default=None, help="run name")
    args = parser.parse_args()
    train(resume_checkpoint=args.resume, run_name=args.name)
