# ablation_runner.py
import os
from train import train
from utils import ensure_dirs, timestamp
ensure_dirs(["outputs", "checkpoints"])

# this runner will do multiple small training runs with different hyperparams
# these are short runs intended for comparison not full training

configs = [
    {"name": "lr_3e-4_warm200", "learning_rate": 3e-4, "warmup_steps": 200, "max_iters": 2000},
    {"name": "lr_1e-4_warm200", "learning_rate": 1e-4, "warmup_steps": 200, "max_iters": 2000},
    {"name": "lr_3e-4_warm0", "learning_rate": 3e-4, "warmup_steps": 0, "max_iters": 2000},
]

if __name__ == "__main__":
    import subprocess, json
    for cfg in configs:
        run_name = cfg["name"] + "_" + timestamp()
        print("starting", run_name)
        cmd = f"python train_full.py --name {run_name}"
        print("run with command", cmd)
    print("ablation runner printed commands above run them one by one to evaluate")
