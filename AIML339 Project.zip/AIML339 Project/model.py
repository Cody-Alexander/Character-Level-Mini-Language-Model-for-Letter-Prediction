# model.py
import torch
import torch.nn as nn
from config import vocab_size, block_size, embed_dim, n_heads, n_layers, dropout, device


# single attention head
class SelfAttentionHead(nn.Module):
    def __init__(self, head_size, return_attention=False):
        super().__init__()
        # linear layers to produce key, query, and value vectors
        self.key = nn.Linear(embed_dim, head_size, bias=False)
        self.query = nn.Linear(embed_dim, head_size, bias=False)
        self.value = nn.Linear(embed_dim, head_size, bias=False)
        # lower triangular mask to prevent attending to future tokens
        self.register_buffer("tril", torch.tril(torch.ones(block_size, block_size)))
        # dropout to reduce overfitting
        self.dropout = nn.Dropout(dropout)
        # flag to return attention weights(for visualization)
        self.return_attention = return_attention
        self.last_attention = None  # stored for visualization

    def forward(self, x):
        B, T, C = x.shape #batch size, sequence length, embedding dim
        # compute key, query, and value projections
        k = self.key(x)
        q = self.query(x)
        # compute raw attention scores
        wei = q @ k.transpose(-2, -1) / (C ** 0.5)
        # apply causal mask to prevent using future context
        wei = wei.masked_fill(self.tril[:T, :T] == 0, float('-inf'))
        # normalize attention scores
        wei = torch.softmax(wei, dim=-1)
        # apply dropout to attention weights
        wei = self.dropout(wei)
        v = self.value(x)
        out = wei @ v
        if self.return_attention:
            self.last_attention = wei.detach().cpu()
        return out


# multihead attention
class MultiHeadAttention(nn.Module):
    def __init__(self, num_heads, head_size):
        super().__init__()
        # create a list of attention heads
        self.heads = nn.ModuleList([
            SelfAttentionHead(head_size, return_attention=True)
            for _ in range(num_heads)
        ])
        # linear projection to mix head outputs
        self.proj = nn.Linear(embed_dim, embed_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        # run each head in parallel and concatenate results
        out = torch.cat([h(x) for h in self.heads], dim=-1)
        out = self.dropout(self.proj(out))
        return out


# feed forward block
class FeedForward(nn.Module):
    def __init__(self):
        super().__init__()
        # two linear layers with relu and dropout in between
        self.net = nn.Sequential(
            nn.Linear(embed_dim, 4 * embed_dim),
            nn.ReLU(),
            nn.Linear(4 * embed_dim, embed_dim),
            nn.Dropout(dropout),
        )

    def forward(self, x):
        return self.net(x)


# transformer block
class Block(nn.Module):
    def __init__(self):
        super().__init__()
        head_size = embed_dim // n_heads
        # multihead attention and feedforward sublayers
        self.sa = MultiHeadAttention(n_heads, head_size)
        self.ffwd = FeedForward()
        # layer normalization before each sublayer
        self.ln1 = nn.LayerNorm(embed_dim)
        self.ln2 = nn.LayerNorm(embed_dim)

    def forward(self, x):
        x = x + self.sa(self.ln1(x))
        x = x + self.ffwd(self.ln2(x))
        return x

# transformer model
class TransformerModel(nn.Module):
    def __init__(self):
        super().__init__()
        # embedding layers for tokens and positions
        self.token_embedding = nn.Embedding(vocab_size, embed_dim)
        self.position_embedding = nn.Embedding(block_size, embed_dim)
        # stack of transformer blocks
        self.blocks = nn.Sequential(*[Block() for _ in range(n_layers)])
        # final normalization and output projection
        self.ln_f = nn.LayerNorm(embed_dim)
        self.head = nn.Linear(embed_dim, vocab_size)

    def forward(self, idx, targets=None):
        B, T = idx.shape # batch size and sequence length
        # look up embeddings for tokens and positions
        tok_emb = self.token_embedding(idx)
        pos = torch.arange(T, device=device)
        pos_emb = self.position_embedding(pos)[None, :, :]
        # combine token and positional embeddings
        x = tok_emb + pos_emb
        # pass through transformer blocks
        x = self.blocks(x)
        # apply final layer norm and project to vocab size
        x = self.ln_f(x)
        logits = self.head(x)

        if targets is None:
            return logits, None

        # compute cross-entropy loss if targets provided
        B, T, C = logits.shape
        logits = logits.view(B*T, C)
        targets = targets.view(B*T)
        loss = nn.functional.cross_entropy(logits, targets)
        return logits, loss
