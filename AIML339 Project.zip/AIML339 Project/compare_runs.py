# compare_runs.py
import os
import matplotlib.pyplot as plt
from utils import load_json
from train import compute_checkpoint_metrics
from utils import ensure_dirs
ensure_dirs(["outputs"])
import argparse

def compare(checkpoint_a, checkpoint_b, label_a="base", label_b="finetuned", outdir="outputs"):
    ma = compute_checkpoint_metrics(checkpoint_a)
    mb = compute_checkpoint_metrics(checkpoint_b)
    print(f"metrics {label_a}: {ma}")
    print(f"metrics {label_b}: {mb}")

    # bar plots for loss accuracy perplexity
    import numpy as np
    labels = ["loss", "accuracy", "perplexity"]
    a_vals = [ma["loss"], ma["accuracy"], ma["perplexity"]]
    b_vals = [mb["loss"], mb["accuracy"], mb["perplexity"]]

    x = np.arange(len(labels))
    width = 0.35
    fig, ax = plt.subplots()
    ax.bar(x - width/2, a_vals, width, label=label_a)
    ax.bar(x + width/2, b_vals, width, label=label_b)
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.legend()
    plt.title("checkpoint comparison")
    path = os.path.join(outdir, f"compare_{label_a}_vs_{label_b}.png")
    plt.savefig(path)
    plt.close()
    print("comparison saved to", path)

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--a", required=True, help="checkpoint a")
    parser.add_argument("--b", required=True, help="checkpoint b")
    parser.add_argument("--la", default="base")
    parser.add_argument("--lb", default="finetuned")
    args = parser.parse_args()
    compare(args.a, args.b, args.la, args.lb)
