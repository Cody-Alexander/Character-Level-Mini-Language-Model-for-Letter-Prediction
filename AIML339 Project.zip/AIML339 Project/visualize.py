# visualize.py
import torch
import matplotlib.pyplot as plt
import seaborn as sns
import os
from model import TransformerModel
from config import device, block_size
from data import encode, decode, itos

os.makedirs("outputs", exist_ok=True)

def load_model(path):
    m = TransformerModel().to(device)
    m.load_state_dict(torch.load(path, map_location=device))
    return m

def attention_heatmaps(model, prompt="ROMEO:", save_prefix="outputs/attention"):
    # run model once to populate last_attention fields
    idx = torch.tensor([encode(prompt)], dtype=torch.long, device=device)
    _logits, _ = model(idx)  # forward
    # iterate blocks and heads
    for bi, block in enumerate(model.blocks):
        sa = block.sa
        for hi, head in enumerate(sa.heads):
            if head.last_attention is None:
                continue
            attn = head.last_attention[0].numpy()  # [T, T]
            plt.figure(figsize=(6,5))
            sns.heatmap(attn, cmap="viridis")
            plt.title(f"block{bi}_head{hi}")
            fname = f"{save_prefix}_block{bi}_head{hi}.png"
            plt.savefig(fname)
            plt.close()
            print("saved", fname)

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--ckpt", required=True)
    parser.add_argument("--prompt", default="ROMEO:")
    args = parser.parse_args()
    m = load_model(args.ckpt)
    attention_heatmaps(m, prompt=args.prompt)
