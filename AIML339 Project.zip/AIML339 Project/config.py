# config.py
import torch

# general configuration
vocab_file = "input.txt"  # tiny shakespeare dataset
seed = 12345  # reproducibility
device = "cuda" if torch.cuda.is_available() else "cpu"

# model hyperparameters
block_size = 128
batch_size = 64
embed_dim = 128
n_heads = 4
n_layers = 2
dropout = 0.1

# dataset prep
with open(vocab_file, 'r', encoding='utf-8') as f:
    text = f.read()

chars = sorted(list(set(text)))
vocab_size = len(chars)
